

<html>
    <head>
        <title>
            Sign In
        </title>
        <link rel="stylesheet" type="text/css" href="css/login.css">
    </head>
    <body>
        <section class="main">
            <img id="logo" src="media/image/SupertechLogo.gif">
            <h1 id="company-name"> Supertech Trading Co.</h1>
            <form action="index.php" method="POST" id="login-form">
                <p><input type="text" name="username" id="username" value="" placeholder="Username" maxlength="20"></p>
                <p><input type="password" name="password" id="password" value="" placeholder="Password" maxlength="20"></p>
            </form>
        </section>
    </body>
        
</html>

